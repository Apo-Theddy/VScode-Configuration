# Operator-Mono-font-family-
this font family is free to use , 

how to do this? </br>
1, first clone or download this repo.</br>
2, then unzip this file</br>
3, go to unzip folder, and choose your choice</br>
4, Open the choice file , and install it</br>
5, then go to vs code setting, and change font family to Operator Mono </br>

thank you


all rights deserved <p><h2>Google</h2></p>
